# IQ Party design bank — upload instructions for agent

Unzip `IQ-Party-design-bank.zip`. The folder `IQ-Party-design-bank/` is the full repo root.

1. Copy its contents into the IQ-Party git repo root (overwrite if empty).
2. Commit on `main` and push to `https://github.com/sammyswe/IQ-Party.git`.
3. Expected root: `obsidian/`, `docs/`, `.cursor/`, `AGENTS.md`, `AGENT_LOOP_ROADMAP.md`, `RESTART.md`, `README.md`.
4. Do not add Quizgame runtime (`client/`, `server/`, `shared/`, `hf-treasure-trap/`).
